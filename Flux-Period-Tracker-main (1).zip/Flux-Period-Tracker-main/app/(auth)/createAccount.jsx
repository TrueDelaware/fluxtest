import { ScrollView, Text, View, TouchableOpacity, Image } from "react-native";
import React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import FormField from "../../components/FormField";
import { styled } from "nativewind";
const StyledView = styled(View);

const createAccount = () => {
  return (
    <SafeAreaView>
      <ScrollView>
        <View className="items-center">
          <View className="relative">
            <Image
              source={require("../../assets/icons/7.png")}
              style={{
                width: 120,
                height: 120,
                borderRadius: 60,
                marginBottom: 10,
              }}
            />
            <TouchableOpacity className="absolute bottom-2 right-0 rounded-full p-1">
              <Image
                source={require("../../assets/icons/Edit.png")}
                style={{ width: 35, height: 35 }}
              />
            </TouchableOpacity>
          </View>
          <StyledView className="container rounded-lg bg-secondary-100 items-center w-[350] p-4">
            <FormField title="Name" otherStyles="mt-2" placeholder="Name" />
            <FormField title="Email" otherStyles="mt-2" placeholder="Email" />
            <FormField
              title="Birthday"
              otherStyles="mb-2 mt-2"
              placeholder="MM/DD/YYY"
            />
            <FormField
              title="Password"
              otherStyles="mb-2"
              placeholder="Password"
            />
            <FormField
              title="Re-enter password"
              otherStyles="mb-2"
              placeholder="Password"
            />

            <TouchableOpacity className="bg-primary rounded-3xl items-center p-3 w-[200] h-[50] mt-5">
              <Text className="text-white text-center text-lg font-semibold">
                Create Account
              </Text>
            </TouchableOpacity>
          </StyledView>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default createAccount;
