import React, { useState } from 'react';
import { Text, View, TextInput, Button } from 'react-native';

// used https://reactnative.dev/docs/getting-started to run this bc installing is hard atm

const flux = () => {
  // Define state variables for user inputs
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  // Function to handle submission
  const handleSubmit = () => {
    console.log(`User Info: ${firstName} ${lastName}, Phone: ${phoneNumber}`);
    alert(`Welcome to Flux, ${firstName}!`);
  };

  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
      }}>
      <Text style={{ fontSize: 24, marginBottom: 20 }}>Welcome to Flux</Text>

      {/* Input field for First Name */}
      <TextInput
        style={{
          height: 40,
          borderColor: 'gray',
          borderWidth: 1,
          width: '80%',
          marginBottom: 10,
          paddingLeft: 8,
        }}
        placeholder="Enter First Name"
        value={firstName}
        onChangeText={text => setFirstName(text)}
      />

      {/* Input field for Last Name */}
      <TextInput
        style={{
          height: 40,
          borderColor: 'gray',
          borderWidth: 1,
          width: '80%',
          marginBottom: 10,
          paddingLeft: 8,
        }}
        placeholder="Enter Last Name"
        value={lastName}
        onChangeText={text => setLastName(text)}
      />

      {/* Input field for Phone Number */}
      <TextInput
        style={{
          height: 40,
          borderColor: 'gray',
          borderWidth: 1,
          width: '80%',
          marginBottom: 20,
          paddingLeft: 8,
        }}
        placeholder="Enter Phone Number"
        keyboardType="phone-pad"
        value={phoneNumber}
        onChangeText={text => setPhoneNumber(text)}
      />

      {/* Submit Button */}
      <Button title="Submit" onPress={handleSubmit} />
    </View>
  );
};

export default flux;
