import eye from "../assets/icons/eye.png";
import eyeHide from "../assets/icons/eye-hide.png";

export default {
  eye,
  eyeHide,
};
